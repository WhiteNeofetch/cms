import { wrapFunctional } from './utils'

export { default as Comment } from '../../components/Comment.vue'
export { default as ProductCard } from '../../components/ProductCard.vue'
export { default as LayoutsHeader } from '../../components/layouts/Header.vue'

export const LazyComment = import('../../components/Comment.vue' /* webpackChunkName: "components/comment" */).then(c => wrapFunctional(c.default || c))
export const LazyProductCard = import('../../components/ProductCard.vue' /* webpackChunkName: "components/product-card" */).then(c => wrapFunctional(c.default || c))
export const LazyLayoutsHeader = import('../../components/layouts/Header.vue' /* webpackChunkName: "components/layouts-header" */).then(c => wrapFunctional(c.default || c))
