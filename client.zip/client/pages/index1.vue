<template>
  <section class="article">
    <div class="article__bg"></div>
    <div class="article__container">
      <div class="article__title">
        Джон Льюис, гигант гражданских прав, в последний раз пересекает печально
        известный мост Сельма
      </div>
      <div class="article__img">
        <img
          src="../assets/img/article-img_1.png"
          alt="Джон Льюис, гигант гражданских прав, в последний раз пересекает печально известный мост Сельма"
        />
      </div>
      <div class="article__img-info">
        <div class="article__img-time">12 часов назад</div>
        <div class="article__img-author">Каролина Касси</div>
        <div class="article__img-like">
          <img class="icon-like" src="../assets/img/like.svg" alt="like:svg" />
          <span class="like-count">28</span>
        </div>
        <div class="article__img-feedback">
          <img
            class="icon-feedback"
            src="../assets/img/feedback.svg"
            alt="feedback:svg"
          />
          <span class="feedback-count">21</span>
        </div>
      </div>
    </div>
    <div class="article__container">
      <div class="article__content">
        <div class="article__text">
          <p>
            Толпа торжественно наблюдала, как тело члена палаты представителей
            Джона Льюиса пересекло мост Эдмунда Петтуса в последний раз, спустя
            55 лет после того, как икона гражданских прав выступила за мир и
            была жестоко встречена в Сельме, штат Алабама.
          </p>
        </div>
        <div class="article__text">
          <p>
            Военнослужащие вооруженных сил США поместили покойного конгрессмена
            Джорджии и икону гражданских прав на конный кессон в воскресенье в
            африканской методистской епископальной церкви Коричневой часовни.
            Оттуда публике разрешили выстроиться в очередь в честь Льюиса
            примерно на полмили до подножия моста.
          </p>
        </div>
        <div class="article__text">
          <p>
            Член палаты представителей Терри Сьюэлл, доктор медицинских наук,
            поблагодарила семью Льюиса во время церемонии в часовне за то, что
            они так много лет делили конгрессмена с публикой.
          </p>
        </div>
      </div>
    </div>
    <div class="article__wrapper">
      <div class="article__subtitle">
        <p>
          Торжественные толпы наблюдают, как Льюис, скончавшийся в начале этого
          месяца в возрасте 80 лет, переносится в кессоне над мостом Эдмунда
          Петтуса.
        </p>
      </div>
    </div>
    <div class="article__container">
      <div class="image__article">
        <img src="../assets/img/img-1.png" alt="img:1" />
      </div>
      <div class="image__article-text">
        <p>
          Ложу покойного Палаты представителей США Джона Льюиса, пионера
          движения за гражданские права, который умер 17 июля, переносят за
          пределы Часовни Брауна
        </p>
      </div>
      <div class="article__text">
        <p>
          Толпа ждала тело Льюиса у подножия моста, где его встретили солдаты
          штата Алабама, которые благополучно сопроводили его через столицу
          штата и обратно.
        </p>
      </div>
      <div class="article__text">
        <p>
          «Его последний марш, этот последний переход, столь непохожий на
          первый, говорит о наследии, которое он оставил, и жизнях, которые он
          изменил», - сказал Сьюэлл. «Это поэтическая справедливость, что на
          этот раз солдаты штата Алабама проведут Джона в его безопасности».
        </p>
      </div>
      <div class="article__text">
        <p>
          Когда кессон, запряженный лошадьми, приближался к мосту, было слышно,
          как люди в толпе на тротуаре поют для Льюиса. В какой-то эмоциональный
          момент голоса прекратились, когда шкатулка Льюиса начала продвигаться
          по мосту в безмолвном благоговении.
        </p>
      </div>
      <div class="article__text">
        <p>
          Льюис, который умер в начале этого месяца в возрасте 80 лет, совершил
          свое последнее путешествие по мосту Эдмунда Петтуса, и только его
          семья присоединилась к нему.
        </p>
      </div>
      <div class="image__article">
        <img src="../assets/img/img-2.png" alt="img:2" />
      </div>
      <div class="image__article-text">
        <p>
          Толпа ждала тело Льюиса у подножия моста, где он находился. Гроб
          конгрессмена Джона Льюиса передвигается по мосту Эдмунда Петтуса на
          конном экипаже во время поминальной службы по Льюису в Сельме, штат
          Алабама, 26 июля 2020 г.
        </p>
      </div>
      <div class="article__text">
        <p>
          Законодатель, избранный на 16-й срок, которого часто называют совестью
          Конгресса, был гигантом движения за гражданские права 1960-х годов.
          Льюису было всего 25, когда он считал, что солдаты Алабамы убьют его
          во время мирного марша за право голоса через мост 7 марта 1965 года,
          известного сегодня как «Кровавое воскресенье».
        </p>
      </div>
      <div class="article__text article-last">
        <p>
          Льюис получил перелом черепа и был одним из десятков
          госпитализированных участников ненасильственных протестов. Освещение
          жестоких избиений в новостях вызвало усиление давления на Конгресс с
          целью принятия Закона об избирательных правах 1965 года, запрещающего
          штатам применять дискриминационные законы, которые долгое время мешали
          потенциальным чернокожим избирателям.
        </p>
      </div>
    </div>
  </section>
</template>
<style lang='scss'>
ul[class],
ol[class] {
  list-style: none;
}

a:not([class]) {
  text-decoration-skip-ink: auto;
}

img {
  max-width: 100%;
  display: block;
}
input,
button,
textarea,
select {
  font: inherit;
}

@media (prefers-reduced-motion: reduce) {
  * {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }
}

.article__bg {
  background-color: #0e1e32;
  width: 100%;
  height: 410px;
  position: absolute;
}

.article__container {
  max-width: 1170px;
  margin: 0px auto;
  position: relative;
}

.article__title {
  font-family: IBM Plex Serif;
  font-weight: 600;
  font-size: 42px;
  line-height: 55px;
  color: #fff;
  padding-top: 63px;
}

.article__inner {
  top: 0px;
  position: absolute;
  left: 0px;
  right: 0px;
}

.article__img {
  padding-top: 34px;
}

.article__img-info {
  display: flex;
  padding-left: 60px;
}

.article__img-time {
  font-family: Poppins;
  font-size: 13px;
  line-height: 165%;
  margin-right: 9px;
}

.article__img-author {
  font-size: 13px;
  line-height: 165%;
  opacity: 0.7;
  margin-right: 9px;
}

.article__img-like,
.article__img-feedback {
  display: flex;
  align-items: center;
}

.article__img-info {
  padding-top: 11px;
}

span.like-count {
  margin-left: 13px;
  margin-right: 13px;
}

span.feedback-count {
  margin-left: 13px;
}

.article__content {
  padding-top: 44px;
  max-width: 705px;
  margin: 0px auto;
}

.article__text:not(:last-child) {
  margin-bottom: 35px;
}

.article__text {
  max-width: 705px;
  font-family: Nunito Sans;
  font-size: 18px;
  line-height: 27px;
  margin: 0px auto;
}

.article__text p {
  font-size: inherit;
}

.article-last {
  padding-bottom: 75px;
}

.article__wrapper {
  margin-top: 85px;
  border-top: 2px solid #c31815;
  border-bottom: 2px solid #c31815;
}

.article__subtitle {
  max-width: 705px;
  margin: 0px auto;
  padding-top: 23px;
  padding-bottom: 23px;
  font-family: IBM Plex Serif;
  font-size: 28px;
  line-height: 42px;
}

.article__subtitle p {
  font-size: inherit;
}

.image__article {
  display: flex;
  justify-content: center;
  padding-top: 59px;
  margin: 0 -15px;
}

.image__article-text {
  max-width: 560px;
  margin: 0px auto;
  font-family: Nunito Sans;
  font-size: 14px;
  line-height: 21px;
  padding-top: 10px;
  margin-bottom: 55px;
}

.image__article-text > p::before {
  display: block;
  content: "";
  width: 2px;
  height: 25px;
  background-color: red;
  color: red;
  margin-right: 10px;
  margin-top: 5px;
}

.image__article-text > p:nth-child(1) {
  display: flex;
}

@media (max-width: 1200px) {
  .article__inner {
    padding: 0 20px;
  }
  .article__container {
    max-width: 900px;
  }
}

@media (max-width: 930px) {
  .article__container {
    max-width: 738px;
  }
}

@media (max-width: 768px) {
  .article__bg {
    display: none;
  }
  .article__text {
    font-size: 16px;
  }
  .article__subtitle {
    font-size: 24px;
  }
  .article {
    margin: 0 15px;
  }
  .article__title {
    position: absolute;
    font-size: 24px;
    line-height: 31px;
    max-width: 450px;
  }
  .article__content {
    padding-top: 70px;
  }
  .article__img {
    padding-top: 0px;
    margin: 0 -15px;
  }
  .article__img-info {
    padding-left: 0px;
  }
}

@media (max-width: 580px) {
  .article__bg {
    display: none;
  }
  .article__title {
    position: absolute;
    font-size: 24px;
    line-height: 31px;
    max-width: 450px;
    padding-top: 30px;
  }
  .article__img {
    padding-top: 0px;
  }
}

@media (max-width: 400px) {
  .article__title {
    font-size: 22px;
    line-height: 28px;
    padding-top: 30px;
  }
  span.feedback-count {
    margin-left: 5px;
  }
  span.like-count {
    margin-left: 5px;
  }
}

@media (max-width: 375px) {
  .article__title {
    font-size: 18px;
    line-height: 26px;
    padding-top: 20px;
    max-width: 295px;
  }
  .article__content {
    padding-top: 40px;
  }
}

@media (max-width: 360px) {
  .article__subtitle {
    font-size: 18px;
  }
  .article__title {
    font-size: 13px;
    line-height: 19px;
    padding-top: 17px;
    max-width: 295px;
  }
  .article__img-time {
    font-size: 8px;
  }
  .article__img-author {
    font-size: 8px;
  }
  .icon-like,
  .icon-feedback {
    width: 10px;
  }
  .like-count,
  .feedback-count {
    font-size: 8px;
  }
}
</style>